package com.asdtechlabs.bloodbank;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;
import android.widget.Toast;

import com.google.android.gms.common.api.ApiException;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AutocompletePrediction;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.google.android.libraries.places.api.model.RectangularBounds;
import com.google.android.libraries.places.api.model.TypeFilter;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import org.w3c.dom.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PostSignIn extends AppCompatActivity implements View.OnClickListener{
    String bloodGroup= " ",fullName;
    EditText name, locationSearch;
    TextView ap,an,bp,bn,abp,abn,op,on,donateBlood,recieveBlood, proceed;
    Geocoder geocoder = new Geocoder(this);
    static Boolean isName=false,isLocation=false,isBloodGroup=false,isAction=false,isDonate=false;
    private static final String TAG = "MapActivity";
    String query;
    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final float DEFAULT_ZOOM = 15f;
    private static final LatLngBounds LAT_LNG_BOUNDS = new LatLngBounds(
            new LatLng(-40, -168), new LatLng(71, 136));


    //widgets
    private AutoCompleteTextView mSearchText;
    private ImageView mGps;

    //vars
    private Boolean mLocationPermissionsGranted = false;
    private GoogleMap mMap;
    private FusedLocationProviderClient mFusedLocationProviderClient;




    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_post_sign_in);

       // getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.id.toolbar_title);
        locationSearch = findViewById(R.id.location);
        name = findViewById(R.id.name);
        locationSearch.addTextChangedListener(locationTextWatcher);
        name.addTextChangedListener(generalTextWatcher);

        String userLocation = String.valueOf(locationSearch.getText());

        proceed = findViewById(R.id.proceed);



        ap = findViewById(R.id.ap);
        an = findViewById(R.id.an);
        bp = findViewById(R.id.bp);
        bn = findViewById(R.id.bn);
        abp = findViewById(R.id.abp);
        abn = findViewById(R.id.abn);
        op = findViewById(R.id.op);
        on = findViewById(R.id.on);
        donateBlood = findViewById(R.id.donate);
        recieveBlood = findViewById(R.id.seek);

        ap.setOnClickListener((View.OnClickListener) this);
        an.setOnClickListener((View.OnClickListener) this);
        bp.setOnClickListener((View.OnClickListener) this);
        bn.setOnClickListener((View.OnClickListener) this);
        abp.setOnClickListener((View.OnClickListener) this);
        abn.setOnClickListener((View.OnClickListener) this);
        op.setOnClickListener((View.OnClickListener) this);
        on.setOnClickListener((View.OnClickListener) this);


        //Google Maps

        getLocationPermission();



    }



    public void Proceed(View view)
    {
        FirebaseUser user= FirebaseAuth.getInstance().getCurrentUser();
        String uId = user.getUid();
        String contactNumber = user.getPhoneNumber();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        Map<String, Object> userDetails = new HashMap<>();
        userDetails.put("name", fullName);
        userDetails.put("contactNumber", contactNumber);
        userDetails.put("bloodGroup", bloodGroup);

        db.collection("users").document(uId)
                .set(userDetails)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully written!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });


        Intent intent = new Intent(PostSignIn.this, MainActivity.class);
            startActivity(intent);
        
    }

    @Override
    public void onClick(View v) {

        isBloodGroup=true;

        isCheck();
        

        ap.setBackgroundResource(R.drawable.blood_group);
        an.setBackgroundResource(R.drawable.blood_group);
        bp.setBackgroundResource(R.drawable.blood_group);
        bn.setBackgroundResource(R.drawable.blood_group);
        op.setBackgroundResource(R.drawable.blood_group);
        on.setBackgroundResource(R.drawable.blood_group);
        abp.setBackgroundResource(R.drawable.blood_group);
        abn.setBackgroundResource(R.drawable.blood_group);

        ap.setTextAppearance(MyApplication.getAppContext(),R.style.BloodGroup);
        an.setTextAppearance(MyApplication.getAppContext(),R.style.BloodGroup);
        bp.setTextAppearance(MyApplication.getAppContext(),R.style.BloodGroup);
        bn.setTextAppearance(MyApplication.getAppContext(),R.style.BloodGroup);
        op.setTextAppearance(MyApplication.getAppContext(),R.style.BloodGroup);
        on.setTextAppearance(MyApplication.getAppContext(),R.style.BloodGroup);
        abp.setTextAppearance(MyApplication.getAppContext(),R.style.BloodGroup);
        abn.setTextAppearance(MyApplication.getAppContext(),R.style.BloodGroup);


        switch(v.getId()){

            case R.id.ap:

                ap.setBackgroundResource(R.drawable.button_red_activated);
                ap.setTextAppearance(MyApplication.getAppContext(),R.style.ButtonActiveBottom);
                bloodGroup = "A+";
                break;
            case R.id.an:
                an.setBackgroundResource(R.drawable.button_red_activated);
                an.setTextAppearance(MyApplication.getAppContext(),R.style.ButtonActiveBottom);
                bloodGroup = "A-";
                break;
            case R.id.bp:
                bp.setBackgroundResource(R.drawable.button_red_activated);
                bp.setTextAppearance(MyApplication.getAppContext(),R.style.ButtonActiveBottom);
                bloodGroup = "B+";
                break;
            case R.id.bn:
                bn.setBackgroundResource(R.drawable.button_red_activated);
                bn.setTextAppearance(MyApplication.getAppContext(),R.style.ButtonActiveBottom);
                bloodGroup = "B-";
                break;
            case R.id.abp:
                abp.setBackgroundResource(R.drawable.button_red_activated);
                abp.setTextAppearance(MyApplication.getAppContext(),R.style.ButtonActiveBottom);
                bloodGroup = "AB+";
                break;
            case R.id.abn:
                abn.setBackgroundResource(R.drawable.button_red_activated);
                abn.setTextAppearance(MyApplication.getAppContext(),R.style.ButtonActiveBottom);
                bloodGroup = "AB-";
                break;
            case R.id.op:
                op.setBackgroundResource(R.drawable.button_red_activated);
                op.setTextAppearance(MyApplication.getAppContext(),R.style.ButtonActiveBottom);
                bloodGroup = "O+";
                break;
            case R.id.on:

                on.setBackgroundResource(R.drawable.button_red_activated);
                on.setTextAppearance(MyApplication.getAppContext(),R.style.ButtonActiveBottom);
                bloodGroup = "O-";
                break;



        }
    }


    public void donateBlood(View v)
    {

        isAction=true;
        isDonate=true;
        isCheck();
        
        donateBlood.setBackgroundResource(R.drawable.button_red_activated);
        donateBlood.setTextAppearance(MyApplication.getAppContext(),R.style.ButtonActiveBottom);
        recieveBlood.setBackgroundResource(R.drawable.blood_group);
        recieveBlood.setTextAppearance(MyApplication.getAppContext(),R.style.BloodGroup);
    }
    public void seekBlood(View v)
    {
        isDonate=false;
        isAction=true;
        isCheck();
        
        recieveBlood.setBackgroundResource(R.drawable.button_red_activated);
        recieveBlood.setTextAppearance(MyApplication.getAppContext(),R.style.ButtonActiveBottom);
        donateBlood.setBackgroundResource(R.drawable.blood_group);
        donateBlood.setTextAppearance(MyApplication.getAppContext(),R.style.BloodGroup);
    }


    private TextWatcher generalTextWatcher = new TextWatcher() {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {


        }

        @Override
        public void afterTextChanged(Editable s) {
            String string = s.toString();
            isName = !string.equals("");
            fullName  = string;
            isCheck();
            
        }
    };

    private TextWatcher locationTextWatcher = new TextWatcher() {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            query = String.valueOf(s);
            init();


        }

        @Override
        public void afterTextChanged(Editable s) {

            String string = String.valueOf(s);

            isLocation = !string.equals("");
            isCheck();
            
        }
    };

    public void isCheck()
    {
        if (isLocation && isAction && isBloodGroup && isName)
        {
            
            proceed.setBackgroundResource(R.drawable.button_red_activated);
            proceed.setTextAppearance(MyApplication.getAppContext(),R.style.ButtonActiveBottom);

            
        }

        else
        {
            proceed.setBackgroundResource(R.drawable.button_deactive);
            proceed.setTextAppearance(MyApplication.getAppContext(),R.style.Proceed);
        }



    }


    private void init(){
        Log.d(TAG, "init: initializing");

        Places.initialize(getApplicationContext(), "AIzaSyDVFSYg8wA3JhyucT7LjVK_P_ciTFM48hM");

// Create a new Places client instance.
        PlacesClient placesClient = Places.createClient(this);


        // Create a new token for the autocomplete session. Pass this to FindAutocompletePredictionsRequest,
        // and once again when the user makes a selection (for example when calling fetchPlace()).
        AutocompleteSessionToken token = AutocompleteSessionToken.newInstance();

        // Create a RectangularBounds object.
        RectangularBounds bounds = RectangularBounds.newInstance(
                new LatLng(-33.880490, 151.184363),
                new LatLng(-33.858754, 151.229596));
        // Use the builder to create a FindAutocompletePredictionsRequest.
        FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                // Call either setLocationBias() OR setLocationRestriction().
                .setLocationBias(bounds)
                //.setLocationRestriction(bounds)
                //.setCountry("au")
                .setTypeFilter(TypeFilter.ADDRESS)
                .setSessionToken(token)
                .setQuery(query)
                .build();

        placesClient.findAutocompletePredictions(request).addOnSuccessListener((response) -> {
            for (AutocompletePrediction prediction : response.getAutocompletePredictions()) {
                Log.i(TAG, prediction.getPlaceId());
                Log.i(TAG, prediction.getPrimaryText(null).toString());
            }
        }).addOnFailureListener((exception) -> {
            if (exception instanceof ApiException) {
                ApiException apiException = (ApiException) exception;
                Log.e(TAG, "Place not found: " + apiException.getStatusCode());
            }
        });
    }

    private void geoLocate(){
        Log.d(TAG, "geoLocate: geolocating");

        String searchString = mSearchText.getText().toString();

        Geocoder geocoder = new Geocoder(PostSignIn.this);
        List<Address> list = new ArrayList<>();
        try{
            list = geocoder.getFromLocationName(searchString, 1);
        }catch (IOException e){
            Log.e(TAG, "geoLocate: IOException: " + e.getMessage() );
        }

        if(list.size() > 0){
            Address address = list.get(0);

            Log.d(TAG, "geoLocate: found a location: " + address.toString());
            //Toast.makeText(this, address.toString(), Toast.LENGTH_SHORT).show();

        }
    }

    private void getDeviceLocation(){
        Log.d(TAG, "getDeviceLocation: getting the devices current location");

        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        try{
            if(mLocationPermissionsGranted){

                final Task location = mFusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if(task.isSuccessful()){
                            Log.d(TAG, "onComplete: found location!");
                            Location currentLocation = (Location) task.getResult();



                        }else{
                            Log.d(TAG, "onComplete: current location is null");
                            Toast.makeText(PostSignIn.this, "unable to get current location", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }catch (SecurityException e){
            Log.e(TAG, "getDeviceLocation: SecurityException: " + e.getMessage() );
        }
    }



    private void getLocationPermission(){
        Log.d(TAG, "getLocationPermission: getting location permissions");
        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION};

        if(ContextCompat.checkSelfPermission(this.getApplicationContext(),
                FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            if(ContextCompat.checkSelfPermission(this.getApplicationContext(),
                    COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                mLocationPermissionsGranted = true;
            }else{
                ActivityCompat.requestPermissions(this,
                        permissions,
                        LOCATION_PERMISSION_REQUEST_CODE);
            }
        }else{
            ActivityCompat.requestPermissions(this,
                    permissions,
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        Log.d(TAG, "onRequestPermissionsResult: called.");
        mLocationPermissionsGranted = false;

        switch(requestCode){
            case LOCATION_PERMISSION_REQUEST_CODE:{
                if(grantResults.length > 0){
                    for(int i = 0; i < grantResults.length; i++){
                        if(grantResults[i] != PackageManager.PERMISSION_GRANTED){
                            mLocationPermissionsGranted = false;
                            Log.d(TAG, "onRequestPermissionsResult: permission failed");
                            return;
                        }
                    }
                    Log.d(TAG, "onRequestPermissionsResult: permission granted");
                    mLocationPermissionsGranted = true;
                    //initialize our map

                    init();
                }
            }
        }
    }


   public void findAutocompletePredictions(String query)
    {


    }


}
