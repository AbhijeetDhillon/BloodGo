package com.asdtechlabs.bloodbank;

import android.app.Application;
import android.content.Context;

import com.google.firebase.FirebaseApp;

/**
 * Created by Abhijeet on 8/27/2019.
 */

public class MyApplication extends Application {

    private static Context context;

    public void onCreate() {
        super.onCreate();
        MyApplication.context = getApplicationContext();
        FirebaseApp.initializeApp(this);
    }

    public static Context getAppContext() {
        return MyApplication.context;
    }
}
