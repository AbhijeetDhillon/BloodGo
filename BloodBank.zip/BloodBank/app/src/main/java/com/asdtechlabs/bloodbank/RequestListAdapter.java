package com.asdtechlabs.bloodbank;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Abhijeet on 8/21/2019.
 */

public class RequestListAdapter extends RecyclerView.Adapter {

    ArrayList<String> Distance;
    ArrayList<String> Title;
    ArrayList<String> storeCount = new ArrayList<>();
    Context context;
    Boolean isRequestAccepted,isListSelected;
    ImageView callButton;
    TextView trackDonor;
    CardView cardView;
    int selectrequester = -1;
    LinearLayout seekerRequested,donorAccepted,donorLeaving;
    public RequestListAdapter(ArrayList<String> titles, ArrayList<String> distances , Context appContext, Boolean isAccepted,Boolean isSelectAll) {
        Distance = distances;
        Title = titles;
        context = appContext;
        isRequestAccepted = isAccepted;
        isListSelected = isSelectAll;
        storeCount.add(String.valueOf(-450));
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.request_list, viewGroup, false);
        return new RequestListHolder(view);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder viewHolder, final int i) {



        String requestText;
        if(!storeCount.isEmpty() && storeCount.contains(String.valueOf(i))) {

            requestText = "Requested";

        }

        else
        {
            requestText = "Request";

        }

        String distance = Distance.get(i);
        String title = Title.get(i);

        ((RequestListHolder) viewHolder).bind(title,distance,requestText);


    }

    @Override
    public int getItemCount() {
        return Title.size();
    }

    private class RequestListHolder extends RecyclerView.ViewHolder {
        TextView title, distance, request;
        Boolean isRequested = false;

        RequestListHolder(View itemView) {
            super(itemView);
            callButton = itemView.findViewById(R.id.callButton);
            trackDonor = (TextView) itemView.findViewById(R.id.track);
            title = (TextView) itemView.findViewById(R.id.title);
            distance = (TextView) itemView.findViewById(R.id.distance);
            request = itemView.findViewById(R.id.requestBlood);
            cardView = itemView.findViewById(R.id.card_view);


            request.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    selectrequester = getAdapterPosition();

                    if(request.getText().equals("Requested")) {
                        storeCount.remove(String.valueOf(selectrequester));
                    }
                    else
                    {
                        storeCount.add(String.valueOf(selectrequester));
                    }
                    notifyDataSetChanged();
                }
            });
        }

        void bind(String offer, final String Donordistance, String requests) {

            title.setText(offer);
            distance.setText(Donordistance);






            if (isRequestAccepted) {
                callButton.setVisibility(View.VISIBLE);
                trackDonor.setVisibility(View.VISIBLE);
                request.setTextColor(Color.parseColor("#ffffff"));
            }

            else
            {
                if(isListSelected)
                {
                    cardView.setBackgroundResource(R.drawable.request_all);
                    callButton.setVisibility(View.GONE);
                    trackDonor.setVisibility(View.GONE);
                    request.setTextColor(Color.parseColor("#ffffff"));
                }
                else {
                    callButton.setVisibility(View.GONE);
                    trackDonor.setVisibility(View.GONE);

                    if (requests.equals("Requested"))
                    {
                        request.setText(requests);
                        request.setTextColor(Color.parseColor("#FF898989"));
                    }
                    else
                    {
                        request.setText(requests);
                        request.setTextColor(Color.parseColor("#FFFB0F0E"));
                    }

                }
            }







            Log.d("Progress","Reached Bind");
        }
    }
}
