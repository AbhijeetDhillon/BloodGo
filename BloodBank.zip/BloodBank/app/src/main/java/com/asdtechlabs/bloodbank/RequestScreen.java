package com.asdtechlabs.bloodbank;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class RequestScreen extends Fragment implements View.OnClickListener {

    TextView ap,an,bp,bn,abp,abn,op,on,donateBlood,recieveBlood,search;
    EditText date, location, time;
    static Boolean isTime=false,isLocation=false,isBloodGroup=false,isAction=false,isDate=false;
    View v;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         v = inflater.inflate(R.layout.fragment_request_screen, container, false);
        final TextView seekBarValue = v.findViewById(R.id.seekBarValue);
        search = v.findViewById(R.id.searchBlood);



        location = v.findViewById(R.id.location);
        date = v.findViewById(R.id.date);
        time = v.findViewById(R.id.time);
        location.addTextChangedListener(locationTextWatcher);
        date.addTextChangedListener(generalTextWatcher);
        time.addTextChangedListener(timeTextWatcher);
//        String fullName = String.valueOf(name.getText());
//        String userLocation = String.valueOf(location.getText());
        search = v.findViewById(R.id.searchBlood);
        Spinner bottles = v.findViewById(R.id.bottles);

        String[] noOfBottles = new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        ArrayAdapter<String> adapter2= new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, noOfBottles);
        bottles.setAdapter(adapter2);



        ap = v.findViewById(R.id.ap);
        an = v.findViewById(R.id.an);
        bp = v.findViewById(R.id.bp);
        bn = v.findViewById(R.id.bn);
        abp = v.findViewById(R.id.abp);
        abn = v.findViewById(R.id.abn);
        op = v.findViewById(R.id.op);
        on = v.findViewById(R.id.on);
        donateBlood = v.findViewById(R.id.donate);
        recieveBlood = v.findViewById(R.id.seek);

        ap.setOnClickListener((View.OnClickListener) this);
        an.setOnClickListener((View.OnClickListener) this);
        bp.setOnClickListener((View.OnClickListener) this);
        bn.setOnClickListener((View.OnClickListener) this);
        abp.setOnClickListener((View.OnClickListener) this);
        abn.setOnClickListener((View.OnClickListener) this);
        op.setOnClickListener((View.OnClickListener) this);
        on.setOnClickListener((View.OnClickListener) this);
        
        
        SeekBar seekBar = v.findViewById(R.id.progressBar);
        seekBar.setMax(101);
        seekBar.setProgress(10);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {

                // TODO Auto-generated method stub

                if(progress==101) {

                    seekBarValue.setText("100+ kms");
                }
                else
                {
                    seekBarValue.setText(String.valueOf(progress) + "kms");
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }
        });


        return v;

    }




    private void loadFragment(Fragment fragment) {
// create a FragmentManager
        android.support.v4.app.FragmentManager fm = getFragmentManager();
// create a FragmentTransaction to begin the transaction and replace the Fragment
        android.support.v4.app.FragmentTransaction fragmentTransaction = fm.beginTransaction();
// replace the FrameLayout with new Fragment
        fragmentTransaction.replace(R.id.frameLayout, fragment);
        fragmentTransaction.commit(); // save the changes
    }

    @Override
    public void onClick(View v) {

            isBloodGroup = true;

            isCheck();


            ap.setBackgroundResource(R.drawable.blood_group);
            an.setBackgroundResource(R.drawable.blood_group);
            bp.setBackgroundResource(R.drawable.blood_group);
            bn.setBackgroundResource(R.drawable.blood_group);
            op.setBackgroundResource(R.drawable.blood_group);
            on.setBackgroundResource(R.drawable.blood_group);
            abp.setBackgroundResource(R.drawable.blood_group);
            abn.setBackgroundResource(R.drawable.blood_group);

            ap.setTextAppearance(MyApplication.getAppContext(), R.style.BloodGroup);
            an.setTextAppearance(MyApplication.getAppContext(), R.style.BloodGroup);
            bp.setTextAppearance(MyApplication.getAppContext(), R.style.BloodGroup);
            bn.setTextAppearance(MyApplication.getAppContext(), R.style.BloodGroup);
            op.setTextAppearance(MyApplication.getAppContext(), R.style.BloodGroup);
            on.setTextAppearance(MyApplication.getAppContext(), R.style.BloodGroup);
            abp.setTextAppearance(MyApplication.getAppContext(), R.style.BloodGroup);
            abn.setTextAppearance(MyApplication.getAppContext(), R.style.BloodGroup);


            switch (v.getId()) {

                case R.id.ap:

                    ap.setBackgroundResource(R.drawable.button_red_activated);
                    ap.setTextAppearance(MyApplication.getAppContext(), R.style.ButtonActiveBottom);

                    break;
                case R.id.an:
                    an.setBackgroundResource(R.drawable.button_red_activated);
                    an.setTextAppearance(MyApplication.getAppContext(), R.style.ButtonActiveBottom);
                    break;
                case R.id.bp:
                    bp.setBackgroundResource(R.drawable.button_red_activated);
                    bp.setTextAppearance(MyApplication.getAppContext(), R.style.ButtonActiveBottom);
                    break;
                case R.id.bn:
                    bn.setBackgroundResource(R.drawable.button_red_activated);
                    bn.setTextAppearance(MyApplication.getAppContext(), R.style.ButtonActiveBottom);
                    break;
                case R.id.abp:
                    abp.setBackgroundResource(R.drawable.button_red_activated);
                    abp.setTextAppearance(MyApplication.getAppContext(), R.style.ButtonActiveBottom);
                    break;
                case R.id.abn:
                    abn.setBackgroundResource(R.drawable.button_red_activated);
                    abn.setTextAppearance(MyApplication.getAppContext(), R.style.ButtonActiveBottom);
                    break;
                case R.id.op:
                    op.setBackgroundResource(R.drawable.button_red_activated);
                    op.setTextAppearance(MyApplication.getAppContext(), R.style.ButtonActiveBottom);
                    break;
                case R.id.on:

                    on.setBackgroundResource(R.drawable.button_red_activated);
                    on.setTextAppearance(MyApplication.getAppContext(), R.style.ButtonActiveBottom);
                    break;


            }

        }


    private TextWatcher generalTextWatcher = new TextWatcher() {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {


        }

        @Override
        public void afterTextChanged(Editable s) {
            String string = s.toString();
            isDate = !string.equals("");
            isCheck();

        }
    };

    private TextWatcher locationTextWatcher = new TextWatcher() {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {



        }

        @Override
        public void afterTextChanged(Editable s) {

            String string = String.valueOf(s);

            isLocation = !string.equals("");
            isCheck();

        }
    };


    private TextWatcher timeTextWatcher = new TextWatcher() {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {



        }

        @Override
        public void afterTextChanged(Editable s) {

            String string = String.valueOf(s);

            isTime = !string.equals("");
            isCheck();

        }
    };

    public void isCheck()
    {
        if (isLocation && isDate && isBloodGroup && isTime)
        {

            search.setBackgroundResource(R.drawable.button_red_activated);
            search.setTextAppearance(MyApplication.getAppContext(),R.style.ButtonActiveBottom);
            search.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v)
                {
                    loadFragment(new RequestScreen2());
                }
            });

        }

        else
        {
            search.setBackgroundResource(R.drawable.button_deactive);
            search.setTextAppearance(MyApplication.getAppContext(),R.style.Proceed);
        }



    }
    
}


