package com.asdtechlabs.bloodbank;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewParent;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private TextView mTextMessage,mTextMessage2,donateBloodMain,requestBloodMain;

    BottomNavigationItemView navigationDonate,navigationRequest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Getting Device Information
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        donateBloodMain = findViewById(R.id.donateBloodMain);
        requestBloodMain = findViewById(R.id.requestBloodMain);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        //Center Title
        toolbar.setTitleMarginStart((int) (width/4));


        setSupportActionBar(toolbar);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);
        //Bottom Navigation
        //mTextMessage = (TextView) findViewById(R.id.message);


        if(PostSignIn.isDonate)
        {
            donateBloodMain.setBackgroundResource(R.drawable.button_red_activated);
            donateBloodMain.setTextAppearance(MyApplication.getAppContext(), R.style.ButtonActiveBottom);
            requestBloodMain.setTextAppearance(MyApplication.getAppContext(), R.style.BloodGroup);
            requestBloodMain.setBackgroundResource(R.drawable.blood_group);

            loadFragment(new DonorScreen());
        }
        else
        {
            requestBloodMain.setBackgroundResource(R.drawable.button_red_activated);
            requestBloodMain.setTextAppearance(MyApplication.getAppContext(), R.style.ButtonActiveBottom);
            donateBloodMain.setTextAppearance(MyApplication.getAppContext(), R.style.BloodGroup);
            donateBloodMain.setBackgroundResource(R.drawable.blood_group);
            loadFragment(new RequestScreen());
        }




    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.medical) {
            // Handle the camera action
        } else if (id == R.id.about) {

        } else if (id == R.id.contact) {

        } else if (id == R.id.feeback) {

        } else if (id == R.id.facebook) {

        } else if (id == R.id.signout) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }




    private void loadFragment(Fragment fragment) {
// create a FragmentManager
        android.support.v4.app.FragmentManager fm = getSupportFragmentManager();
// create a FragmentTransaction to begin the transaction and replace the Fragment
        android.support.v4.app.FragmentTransaction fragmentTransaction = fm.beginTransaction();
// replace the FrameLayout with new Fragment
        fragmentTransaction.replace(R.id.frameLayout, fragment);
        fragmentTransaction.commit(); // save the changes
    }

    public void DonateBlood(View v)
    {
        donateBloodMain.setBackgroundResource(R.drawable.button_red_activated);
        donateBloodMain.setTextAppearance(MyApplication.getAppContext(), R.style.ButtonActiveBottom);
        requestBloodMain.setTextAppearance(MyApplication.getAppContext(), R.style.BloodGroup);
        requestBloodMain.setBackgroundResource(R.drawable.blood_group);

        loadFragment(new DonorScreen());
    }


    public void RequestBlood(View v)
    {
        requestBloodMain.setBackgroundResource(R.drawable.button_red_activated);
        requestBloodMain.setTextAppearance(MyApplication.getAppContext(), R.style.ButtonActiveBottom);
        donateBloodMain.setTextAppearance(MyApplication.getAppContext(), R.style.BloodGroup);
        donateBloodMain.setBackgroundResource(R.drawable.blood_group);
        loadFragment(new RequestScreen());
    }
}
