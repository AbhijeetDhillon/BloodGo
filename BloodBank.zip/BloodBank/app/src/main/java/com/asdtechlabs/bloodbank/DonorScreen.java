package com.asdtechlabs.bloodbank;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class DonorScreen extends Fragment implements View.OnClickListener {
    ArrayList<String> seekerName = new ArrayList<String>();
    ArrayList<String> bottlesRequired = new ArrayList<>();
    ArrayList<String> Date = new ArrayList<>();
    ArrayList<String> Location = new ArrayList<>();
    TextView request, track, requestAll;

    static TextView accepted, newRequests, noRequest;;
    ImageView call;
    View v,vs;
    static CardView cardView;
    static FrameLayout frame;
    static Boolean isAccepted;
    static RecyclerView mRecycler;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_donor_screen, container, false);
        vs = inflater.inflate(R.layout.donor_requests, container, false);//isSelectAll = false;

        frame = v.findViewById(R.id.replace);
        noRequest = v.findViewById(R.id.noRequests);

        for (int i = 1; i <= 10; i++) {
            seekerName.add("Person" + i);
        }


        for (int i = 1; i <= 10; i++) {
            bottlesRequired.add(i + "Bottles");
        }

        for (int i = 1; i <= 10; i++) {
            Date.add(i + "pm : Monday");
        }
        for (int i = 1; i <= 10; i++) {
            Location.add("Location" +i);
        }



        newRequests = v.findViewById(R.id.donor);
        request = v.findViewById(R.id.requestBlood);
        call = v.findViewById(R.id.callButton);
        track = v.findViewById(R.id.track);
        requestAll = v.findViewById(R.id.requestall);
        cardView = (CardView) vs.findViewById(R.id.card_view_Donor);
        accepted = v.findViewById(R.id.acceptedRequest);

        newRequests.setOnClickListener((View.OnClickListener) this);
        accepted.setOnClickListener((View.OnClickListener) this);
        showList();
        noRequest.setText("No New Requests");
        return v;

    }


    @Override
    public void onClick(View v) {
        AppCompatActivity activity;
        frame.setVisibility(View.VISIBLE);
        noRequest.setVisibility(View.GONE);
        cardView.setVisibility(View.GONE);
        mRecycler.setVisibility(View.VISIBLE);
        isAccepted = false;
        switch (v.getId()) {

            case R.id.donor:
                highlight();
                showList();
                break;

            case R.id.acceptedRequest:
                frame.setVisibility(View.GONE);
                cardView.setVisibility(View.VISIBLE);
                noRequest.setText("No Accepted Requests");
                noRequest.setVisibility(View.VISIBLE);
                isAccepted = true;
                highlight();
                DonorCardView donorCardView = new DonorCardView();
                activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.replace, donorCardView).addToBackStack(null).commit();
                break;
            

        }
    }

    public void showList() {
        mRecycler = (RecyclerView) v.findViewById(R.id.recylerviewDonor);
        DonorListAdapter mDonorListAdapter = new DonorListAdapter(seekerName, bottlesRequired,Date,Location, getContext());
        mRecycler.setAdapter(mDonorListAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        mRecycler.setLayoutManager(layoutManager);
    }

    public static void highlight()
    {
       if(isAccepted)
        {
            accepted.setTextAppearance(MyApplication.getAppContext(),R.style.Donors);
            accepted.setBackgroundResource(R.drawable.redhighlighter);
            newRequests.setTextAppearance(MyApplication.getAppContext(),R.style.Accepted);
            newRequests.setBackgroundColor(Color.parseColor("#FFFAFAFA"));

        }

        else
        {
            newRequests.setTextAppearance(MyApplication.getAppContext(),R.style.Donors);
            newRequests.setBackgroundResource(R.drawable.redhighlighter);
            accepted.setTextAppearance(MyApplication.getAppContext(),R.style.Accepted);
            accepted.setBackgroundColor(Color.parseColor("#FFFAFAFA"));
        }
    }
}