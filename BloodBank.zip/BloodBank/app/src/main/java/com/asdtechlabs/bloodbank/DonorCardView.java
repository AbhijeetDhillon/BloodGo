package com.asdtechlabs.bloodbank;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import static com.asdtechlabs.bloodbank.DonorScreen.noRequest;

/**
 * Created by Abhijeet on 8/26/2019.
 */

public class DonorCardView extends Fragment {


    TextView SeekerName, Date, noOfBottles,location, iAmComing, notComing, iHaveDonated;
    ImageView callButton;
    static LinearLayout infoOfDonation;
    View v,vs;
    LinearLayout donorAccepted, donorRequested,donorDonated;
    CardView cardView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.donor_requests, container, false);
        vs = inflater.inflate(R.layout.fragment_donor_screen, container, false);
        DonorScreen.isAccepted = true;
        DonorScreen.highlight();

        callButton = v.findViewById(R.id.callButton);
        SeekerName = (TextView) v.findViewById(R.id.seekerName);
        location = (TextView) v.findViewById(R.id.location);
        Date = v.findViewById(R.id.dateTime);
        noOfBottles = v.findViewById(R.id.noOfBottles);
        donorAccepted = v.findViewById(R.id.donorAccepted);
        donorRequested = v.findViewById(R.id.donorRequested);
        donorDonated = v.findViewById(R.id.donorDonated);
        iAmComing = v.findViewById(R.id.iAmComing);
        iHaveDonated = v.findViewById(R.id.iHaveDonated);
        notComing = v.findViewById(R.id.notComing);
        infoOfDonation = v.findViewById(R.id.infoOfDonation);
        Bundle arguments = getArguments();
        infoOfDonation.setVisibility(View.GONE);
        cardView =  v.findViewById(R.id.card_view_Donor);

        String name = null,dateofDonation = null,bottles = null,place = null;
        if(arguments!=null) {

            infoOfDonation.setVisibility(View.VISIBLE);
             name = arguments.getString("seekerName");
             dateofDonation = arguments.getString("date");
             bottles = arguments.getString("bottles");
             place = arguments.getString("location");


            SeekerName.setText(name);
            Date.setText(dateofDonation);
            noOfBottles.setText(bottles);
            location.setText(place);

            donorRequested.setVisibility(View.GONE);
            donorAccepted.setVisibility(View.VISIBLE);




            iAmComing.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getContext());
// ...Irrelevant code for customizing the buttons and title
                    LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    final View dialogView = inflater.inflate(R.layout.dialogcustom_donor_depature, null);
                    dialogBuilder.setView(dialogView);
                    final AlertDialog alertDialog = dialogBuilder.create();
                    alertDialog.show();

                    TextView continueDonation = dialogView.findViewById(R.id.donorLeft);
                    TextView close = dialogView.findViewById(R.id.goBack);

                    continueDonation.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            DonorScreen.mRecycler.setVisibility(View.GONE);
                            donorAccepted.setVisibility(View.GONE);
                            donorDonated.setVisibility(View.VISIBLE);
                            finalState();
                            alertDialog.dismiss();

                        }
                    });

                    close.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            alertDialog.dismiss();

                        }
                    });


                }});

            notComing.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    DonorScreen.frame.setVisibility(View.GONE);
                    cardView.setVisibility(View.GONE);
                    noRequest.setText("No Accepted Requests!");
                    noRequest.setVisibility(View.VISIBLE);


                }
            });


        }







        return v;
    }

    public void finalState() {
        iHaveDonated.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DonorScreen.frame.setVisibility(View.GONE);
                cardView.setVisibility(View.GONE);
                noRequest.setText("Donation Successful, Thank You!");
                noRequest.setVisibility(View.VISIBLE);
            }
        });
    }

}
