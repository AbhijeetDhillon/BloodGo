package com.asdtechlabs.bloodbank;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class RequestScreen2 extends Fragment implements View.OnClickListener{
    ArrayList<String> donorName = new ArrayList<String>();
    ArrayList<String> donorDistance = new ArrayList<>();
    TextView request,track,requestAll,changePreferences;
    static TextView donor,accepted;
    ImageView call;
    View v;
    CheckBox selectAll;
    CardView cardView;
    static Boolean isAccepted, isSelectAll;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_request_screen2, container, false);

        isAccepted = false;
        isSelectAll=false;
        accepted = v.findViewById(R.id.accepted);
        donor = v.findViewById(R.id.donor);
        changePreferences = v.findViewById(R.id.changePreferences);

        for (int i = 1; i <= 10; i++) {
            donorName.add("Person" + i);
        }


        for (int i = 1; i <= 10; i++) {
            donorDistance.add(i + "km");
        }

        RecyclerView mRecycler = (RecyclerView) v.findViewById(R.id.recylerview);
        RequestListAdapter mRequestListAdapter = new RequestListAdapter(donorName,donorDistance, getContext(),isAccepted,isSelectAll);
        mRecycler.setAdapter(mRequestListAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        mRecycler.setLayoutManager(layoutManager);


        request =  v.findViewById(R.id.requestBlood);
        call = v.findViewById(R.id.callButton);
        track = v.findViewById(R.id.track);
        selectAll = v.findViewById(R.id.checkbox);
        requestAll = v.findViewById(R.id.requestall);
        cardView = (CardView) v.findViewById(R.id.card_view);


//
          accepted.setOnClickListener((View.OnClickListener)this);
          selectAll.setOnClickListener((View.OnClickListener)this);
          donor.setOnClickListener((View.OnClickListener)this);
          changePreferences.setOnClickListener((View.OnClickListener)this);


        return v;

    }

//    private final View.OnClickListener mOnClickListener = new MyOnClickListener();
//
//    @Override
//    public MyViewHolder onCreateViewHolder(final ViewGroup parent, final int viewType) {
//        View view = LayoutInflater.from(mContext).inflate(R.layout.myview, parent, false);
//        view.setOnClickListener(mOnClickListener);
//        return new MyViewHolder(view);
//    }




    @Override
    public void onClick(View v) {
        isAccepted = false;
        isSelectAll=false;
        switch (v.getId()) {

            case R.id.donor:

                highlight();
                selectAll.setVisibility(View.VISIBLE);
                requestAll.setVisibility(View.GONE);
                showList(donorName,donorDistance,isAccepted,isSelectAll);

                break;
            case R.id.accepted:
                isAccepted = true;
                highlight();
                selectAll.setVisibility(View.GONE);

                for (int i = 1; i <= 4; i++) {
                    donorName.add("Person" + i);
                }


                for (int i = 1; i <= 4; i++) {
                    donorDistance.add(i + "km");
                }

                requestAll.setVisibility(View.GONE);
                showList(donorName,donorDistance,isAccepted,isSelectAll);
                break;

            case R.id.checkbox:


                selectAll.setVisibility(View.VISIBLE);
                if(selectAll.isChecked()) {
                    requestAll.setVisibility(View.VISIBLE);
                    isSelectAll = true;
                    showList(donorName, donorDistance,isAccepted,isSelectAll);

                }

                else
                {
                    requestAll.setVisibility(View.GONE);
                    isSelectAll = false;
                    showList(donorName,donorDistance,isAccepted,isSelectAll);
                }
                break;

            case R.id.changePreferences:

                android.support.v4.app.FragmentManager fm = getFragmentManager();
// create a FragmentTransaction to begin the transaction and replace the Fragment
                android.support.v4.app.FragmentTransaction fragmentTransaction = fm.beginTransaction();
// replace the FrameLayout with new Fragment
                fragmentTransaction.replace(R.id.frameLayout, new RequestScreen());
                fragmentTransaction.commit(); // save the changes

                break;

        }
    }

    public void showList(ArrayList<String> donorName, ArrayList<String> donorDistance, Boolean isAccepted, Boolean isSelectAll )
    {
        RecyclerView mRecycler = (RecyclerView) v.findViewById(R.id.recylerview);
        RequestListAdapter mRequestListAdapter = new RequestListAdapter(donorName, donorDistance, getContext(), isAccepted, isSelectAll);
        mRecycler.setAdapter(mRequestListAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        mRecycler.setLayoutManager(layoutManager);

    }

    public static void highlight()
    {
        if(isAccepted)
        {
            accepted.setTextAppearance(MyApplication.getAppContext(),R.style.Donors);
            accepted.setBackgroundResource(R.drawable.redhighlighter);
            donor.setTextAppearance(MyApplication.getAppContext(),R.style.Accepted);
            donor.setBackgroundColor(Color.parseColor("#FFFAFAFA"));

        }

        else
        {
            donor.setTextAppearance(MyApplication.getAppContext(),R.style.Donors);
            donor.setBackgroundResource(R.drawable.redhighlighter);
            accepted.setTextAppearance(MyApplication.getAppContext(),R.style.Accepted);
            accepted.setBackgroundColor(Color.parseColor("#FFFAFAFA"));
        }
    }


}
